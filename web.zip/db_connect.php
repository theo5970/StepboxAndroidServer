<?php

    $db_host = "localhost";
    $db_user = "root";
    $db_password = "Rpdlaahqkdlf123!@#";
    $db_name = "stepbox";
    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
?>