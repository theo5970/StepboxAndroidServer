<?php 
    
    $jb_connect = mysqli_connect( 'localhost', 'test', 'Rpdlaahqkdlf123!@#', 'test' );
    var_dump( $jb_connect );
  
?>